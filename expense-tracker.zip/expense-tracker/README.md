# Expense Tracker (CLI)

A simple command-line expense tracker written in Python.  
Store expenses in `expenses.csv`, view them, filter by category/date, get a summary, and export a report.

## Features
- Add new expenses (date, category, amount, note)
- View expenses in a table (uses `tabulate`)
- Filter by category or date range
- Summary (total by category)
- Export to CSV

## Requirements
- Python 3.8+
- Install dependencies:
```
pip install -r requirements.txt
```

## Run
```
python expense_tracker.py
```

## File structure
```
expense-tracker/
├── expense_tracker.py
├── expenses.csv
├── README.md
├── requirements.txt
```

## Future improvements
- Add editing/deleting of records
- Use SQLite for better storage and queries
- Add unit tests and CI
- Build a simple web UI with Flask or FastAPI
