#!/usr/bin/env python3
"""
Expense Tracker CLI
Stores expenses in a CSV file (expenses.csv) and provides basic reports.
Usage: python expense_tracker.py
"""
import csv
from datetime import datetime
from pathlib import Path
from tabulate import tabulate

DATA_FILE = Path(__file__).parent / "expenses.csv"
FIELDNAMES = ["id", "date", "category", "amount", "note"]

def ensure_data_file():
    if not DATA_FILE.exists():
        with DATA_FILE.open("w", newline='', encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()

def read_expenses():
    ensure_data_file()
    with DATA_FILE.open("r", newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)

def write_expense(row):
    ensure_data_file()
    with DATA_FILE.open("a", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writerow(row)

def add_expense():
    now = datetime.now().strftime("%Y-%m-%d")
    date = input(f"Date [{now}]: ").strip() or now
    category = input("Category (e.g., Food, Rent, Transport): ").strip() or "Misc"
    amount = input("Amount: ").strip()
    note = input("Note (optional): ").strip()
    # generate simple id
    expenses = read_expenses()
    next_id = int(expenses[-1]["id"]) + 1 if expenses else 1
    row = {"id": next_id, "date": date, "category": category, "amount": amount, "note": note}
    write_expense(row)
    print("Expense added.")

def view_expenses(filtered=None):
    expenses = read_expenses()
    if filtered is not None:
        expenses = [e for e in expenses if filtered(e)]
    if not expenses:
        print("No expenses found.")
        return
    table = [[e["id"], e["date"], e["category"], e["amount"], e["note"]] for e in expenses]
    print(tabulate(table, headers=FIELDNAMES, tablefmt="github"))

def filter_menu():
    print("Filter options:")
    print("1) By category")
    print("2) By date range")
    choice = input("Choose filter (or Enter to cancel): ").strip()
    if choice == "1":
        cat = input("Category: ").strip()
        view_expenses(filtered=lambda e: e["category"].lower() == cat.lower())
    elif choice == "2":
        start = input("Start date (YYYY-MM-DD): ").strip()
        end = input("End date (YYYY-MM-DD): ").strip()
        def between(e):
            try:
                d = datetime.strptime(e["date"], "%Y-%m-%d").date()
                return (not start or d >= datetime.strptime(start, "%Y-%m-%d").date()) and                        (not end or d <= datetime.strptime(end, "%Y-%m-%d").date())
            except Exception:
                return False
        view_expenses(filtered=between)
    else:
        print("Canceled filter.")

def summary():
    expenses = read_expenses()
    if not expenses:
        print("No expenses to summarize.")
        return
    totals = {}
    for e in expenses:
        cat = e["category"]
        try:
            amt = float(e["amount"])
        except:
            amt = 0.0
        totals[cat] = totals.get(cat, 0.0) + amt
    table = [[cat, f"{totals[cat]:.2f}"] for cat in sorted(totals)]
    print("Spending by category:")
    print(tabulate(table, headers=["Category", "Total"], tablefmt="github"))
    print(f"Overall total: {sum(totals.values()):.2f}")

def export_csv(outpath="report.csv"):
    expenses = read_expenses()
    if not expenses:
        print("No expenses to export.")
        return
    with open(outpath, "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(expenses)
    print(f"Exported to {outpath}")

def menu():
    ensure_data_file()
    while True:
        print("\nExpense Tracker")
        print("1) Add expense")
        print("2) View all expenses")
        print("3) Filter expenses")
        print("4) Summary by category")
        print("5) Export CSV")
        print("0) Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            filter_menu()
        elif choice == "4":
            summary()
        elif choice == "5":
            export_csv()
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print("\nExiting...")
